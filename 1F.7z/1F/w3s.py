from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware
from contract import addresss_contract, ABI
import web3


class CWW():
    def __init__(self):
        self.w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
        if self.w3.is_connected:
            self.w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
            self.contract = self.w3.eth.contract(address=addresss_contract, abi=ABI)
            print("Подлючение к сети было успешно проведенно")
        else:
            print("Подключение к сети было прерванно с некоторыми ошибками")

    # Функции call


    def getPresent(self, Present_id):
        return self.contract.functions.getPresent(Present_id).call()

    def getSell(self, Sel_id):
        return self.contract.functions.getSale(Sel_id).call()

    def get_list_estate(self):
        return self.contract.functions.getListEstate().call()

    # Длина подарков
    def get_list_present(self):
        return self.contract.functions.getListPresent().call()

    # Просмотреть дом по ID
    def estate_info(self, ID_estate):
        return self.contract.functions.estates(ID_estate).call()

    # Посмотреть дедлайн по дарению
    def Present_Time(self):
        return self.contract.functions.presentTime().call()

    # Получить колличество домов в продаже
    def Get_sells_list(self):
        return self.contract.functions.getSellsList().call()

    # Посмотреть ставки на продажу
    def Binds_Sells_list(self, Salle_ID):
        return self.contract.functions.getBidList(Salle_ID).call()

    # Посомтреть всех людей которые поставили ставку на этот дом
    def Customer_sells(self, Salle_ID):
        return self.contract.functions.getCustomerList(Salle_ID).call()

    # Все активные продажи
    def full_sells(self):
        index = self.Get_sells_list()
        result = []
        for i in range(index):
            ID_sells = i
            print(f"{ID_sells}")
            SResult = self.contract.functions.sales(i).call()
            if SResult[2] == "0x0000000000000000000000000000000000000000":
                SResult.append(ID_sells)
                result.append(SResult)
            else:
                pass
        return result

    # Посмотреть активный подарок
    def present_check(self, ID_present):
        return self.contract.functions.presents(ID_present).call()

    # Посмотреть владельца контракта
    def check_admin(self):
        return self.contract.functions.admin().call()

    # Функции с подписью

    # Создать дом
    def create_estate(self, addres_owner, info, square, addres_admin):
        tx = self.contract.functions.createEstate(addres_owner, info, square).transact({"from": addres_admin})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Создание подарка
    def create_presents(self, estateID, adr_to, owner):
        tx = self.contract.functions.createPresent(estateID, adr_to).transact({"from": owner})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Отменить подарок
    def reconsider_present(self, present_id, owner):
        tx = self.contract.functions.reconsiderPresent(present_id).transact({"from": owner})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Принять подарок
    def accept_Present(self, present_id, recipient):
        tx = self.contract.functions.acceptPresent(present_id).transact({"from": recipient})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Отказаться от подарка
    def refuse_present(self, present_id, recipient):
        tx = self.contract.functions.refusePresent(present_id).transact({"from": recipient})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Статус ареста
    def change_arest_stat(self, estate_id, new_status, admin):
        tx = self.contract.functions.changeArestSTAT(estate_id, new_status).transact({"from": admin})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Создание продажи
    def create_sale(self, estate_id, price, owner):
        tx = self.contract.functions.createSale(estate_id, price).transact({"from": owner})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Функция с подпосью транзакции

    # Ставка
    def make_bid(self, price, id_sels, address):
        Ether_price = web3.Web3.from_wei(self.w3.eth.get_balance(address), "ether")
        tx = self.contract.functions.makeBid(id_sels).transact({"from": address, "value": Ether_price})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Отказатсья от ставки
    def refuse_bid(self, sale_id, addres):
        tx = self.contract.functions.refuseBid(sale_id).transact({"from": addres})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Принять ставку
    def accept_bid(self, sale_id, bid_id, addres):
        tx = self.contract.functions.acceptBid(sale_id, bid_id).transact({"from": addres})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Отменить продажу
    def reconsider_sale(self, sale_id, addres):
        tx = self.contract.functions.reconsiderSale(sale_id).transact({"from": addres})
        self.w3.eth.wait_for_transaction_receipt(tx)

    # Функиции с geht

    def Balance_OF(self, address):
        return web3.Web3.from_wei(self.w3.eth.get_balance(address), "ether")
    

    def accounts(self):
        return self.w3.eth.accounts


if __name__ == "__main__":
    css = CWW()
    s = css.accept_Present(5, "0xBD4B1fc1662A3159F16Be06D6bCBbBCe56591B3b")
    print(s)

