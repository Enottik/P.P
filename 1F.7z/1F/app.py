import threading
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QPixmap
import sys
from w3s import CWW
from grafic.MainWindow import Ui_btn_three_tab1
from grafic.sel_info_you import Ui_sel_win
from grafic.sale_you import Ui_sell_you
from check_work import Work



map_status = {
    0: "ACTIVE",
    1: "REFUSE",
    2: "ACCEPT",
    3: "CANEL",
    4: "RECONSIDER"
}


class MyApp(QtWidgets.QApplication):
    def __init__(self, sys_argv):
        super(MyApp, self).__init__(sys_argv)
        self.main_window = None
        self.sel_info_window = None
        self.sel_info_you_window = None
        self.w3w = CWW()
        self.works = Work()
        self.timer = None


    def fill_table(self):
        addres = self.ui_main.comboBox_2.currentText()
        self.ui_main.tab1_tabbel.setRowCount(0)
        estates = self.works.check_owner_estated(addres)
        for estate in estates:
            row_position = self.ui_main.tab1_tabbel.rowCount()
            self.ui_main.tab1_tabbel.insertRow(row_position)
            self.ui_main.tab1_tabbel.setItem(row_position, 0, QtWidgets.QTableWidgetItem(str(estate[6])))  
            self.ui_main.tab1_tabbel.setItem(row_position, 1, QtWidgets.QTableWidgetItem(estate[1]))    
            self.ui_main.tab1_tabbel.setItem(row_position, 2, QtWidgets.QTableWidgetItem(str(estate[2]))) 
            self.ui_main.tab1_tabbel.setItem(row_position, 3, QtWidgets.QTableWidgetItem(str(estate[5]))) 
            self.ui_main.tab1_tabbel.setItem(row_position, 4, QtWidgets.QTableWidgetItem(str(estate[4]))) 
            self.ui_main.tab1_tabbel.setItem(row_position, 5, QtWidgets.QTableWidgetItem(str(estate[3]))) 


        self.ui_main.tab2_tabel.setRowCount(0)
        presents = self.works.check_owner_present(addres)
        for present in presents:
            row_position = self.ui_main.tab2_tabel.rowCount()
            self.ui_main.tab2_tabel.insertRow(row_position)
            self.ui_main.tab2_tabel.setItem(row_position, 0, QtWidgets.QTableWidgetItem(str(present[5])))
            self.ui_main.tab2_tabel.setItem(row_position, 1, QtWidgets.QTableWidgetItem(str(present[0])))
            self.ui_main.tab2_tabel.setItem(row_position, 2, QtWidgets.QTableWidgetItem(str(present[1]))) # s
            self.ui_main.tab2_tabel.setItem(row_position, 3, QtWidgets.QTableWidgetItem(str(present[2])))
            self.ui_main.tab2_tabel.setItem(row_position, 4, QtWidgets.QTableWidgetItem(str(present[3])))
            self.ui_main.tab2_tabel.setItem(row_position, 5, QtWidgets.QTableWidgetItem(str(self.check_who(present[1], addres))))
            self.ui_main.tab2_tabel.setItem(row_position, 6, QtWidgets.QTableWidgetItem(str(map_status[present[4]])))

        self.ui_main.tab3_tabel_sel.setRowCount(0)
        sells = self.works.check_sell(addres)
        for sell in sells:
            row_position = self.ui_main.tab3_tabel_sel.rowCount()
            self.ui_main.tab3_tabel_sel.insertRow(row_position)
            self.ui_main.tab3_tabel_sel.setItem(row_position, 0, QtWidgets.QTableWidgetItem(str(sell[6])))
            self.ui_main.tab3_tabel_sel.setItem(row_position, 1, QtWidgets.QTableWidgetItem(str(sell[0])))
            self.ui_main.tab3_tabel_sel.setItem(row_position, 2, QtWidgets.QTableWidgetItem(str(sell[1])))
            self.ui_main.tab3_tabel_sel.setItem(row_position, 3, QtWidgets.QTableWidgetItem(str(sell[3])))

        self.ui_main.tab3_tabel_sel_you.setRowCount(0)
        sells = self.works.check_owner_sell(addres)
        for sell in sells:
            row_position = self.ui_main.tab3_tabel_sel_you.rowCount()
            self.ui_main.tab3_tabel_sel_you.insertRow(row_position)
            self.ui_main.tab3_tabel_sel_you.setItem(row_position, 0, QtWidgets.QTableWidgetItem(str(sell[6])))
            self.ui_main.tab3_tabel_sel_you.setItem(row_position, 1, QtWidgets.QTableWidgetItem(str(sell[0])))
            self.ui_main.tab3_tabel_sel_you.setItem(row_position, 2, QtWidgets.QTableWidgetItem(str(sell[1])))
            self.ui_main.tab3_tabel_sel_you.setItem(row_position, 3, QtWidgets.QTableWidgetItem(str(sell[3])))



        


    def check_who(self,address, addrress_tabel):
        if address == addrress_tabel:
            return "Ты"
        else:
            return "Тебе"


    def start_tabel_work(self):
        if self.main_window.isVisible():
            print("Task run")
            threading.Timer(30, self.start_tabel_work)
            self.fill_table()
        else:
            print("Task Stop")

    def start_tabel_test(self):
        self.fill_table()



    def check_who(self,address, addrress_tabel):
        if address == addrress_tabel:
            return "Ты"
        else:
            return "Тебе"


    def Main_windows(self):
        self.main_window = QtWidgets.QMainWindow()  
        self.ui_main = Ui_btn_three_tab1()
        self.ui_main.setupUi(self.main_window)
        self.main_window.show()
        self.create_comBox_account()
        self.config_main(self.ui_main.comboBox_2.currentText())
        self.start_tabel_work()
        self.reaction_main()


    def config_main(self,addres):
        balance = self.w3w.Balance_OF(addres)
        balance = "{:.3f}".format(balance)
        self.ui_main.tab1_key.setText(addres)
        self.ui_main.tab_1_balance.setText(f"Balance:\n{str(balance)}")
        self.ui_main.tab2_key.setText(f"key:{addres}")
        self.ui_main.tab_2_balance.setText(f"Balance:\n{str(balance)}")
        self.fill_table()
        self.create_comBox_account_present()

        addres_off = self.w3w.accounts()

        if addres == self.w3w.check_admin():
            pixmap = QPixmap("textur/users.jpg")
            self.ui_main.label_2.setPixmap(pixmap)
        elif addres == addres_off[1]:
            pixmap = QPixmap("textur/channels_profile.jpg")
            self.ui_main.label_2.setPixmap(pixmap)
        elif addres == addres_off[2]:
            pixmap = QPixmap("textur/profile22.jpg")
            self.ui_main.label_2.setPixmap(pixmap)       
        elif addres == addres_off[3]:
            pixmap = QPixmap("textur/profile.jpg")
            self.ui_main.label_2.setPixmap(pixmap)  



        self.ui_main.btn_one_tab1.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(0))
        self.ui_main.btn_two_tab1.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(1))
        self.ui_main.btn_three_tab1_2.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(2))

        self.ui_main.btn_one_tab2.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(0))
        self.ui_main.btn_two_tab2.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(1))
        self.ui_main.btn_three_tab2.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(2))

        self.ui_main.btn_one_tab3.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(0))
        self.ui_main.btn_two_tab3.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(1))
        self.ui_main.btn_three_tab3.clicked.connect(lambda: self.ui_main.stackedWidget.setCurrentIndex(2))


    def reaction_main(self):
        self.ui_main.tab1_restart_btn.clicked.connect(self.fill_table)
        self.ui_main.tab1_restart_btn_2.clicked.connect(self.fill_table)
        self.ui_main.btn_tab2_Otkaz_present.clicked.connect(self.reconsider_presetn)
        self.ui_main.btn_tab2_accet_present.clicked.connect(self.accept_present)
        self.ui_main.btn_canel_tab2.clicked.connect(self.refuse_present)
        self.ui_main.btn_tab2_present_home.clicked.connect(self.create_present)
        self.ui_main.btn_create.clicked.connect(self.create_estate)
        self.ui_main.btn_check_home_tab2.clicked.connect(self.check_home_id)
        self.ui_main.btn_tab2_home_you.clicked.connect(self.check_my_home)
        self.ui_main.comboBox_2.currentTextChanged.connect(self.account_change)
        self.ui_main.tab3_check_sel.clicked.connect(self.Sel_info_windows)



    def check_my_home(self):
        addres= self.ui_main.comboBox_2.currentText()
        result_list = self.works.check_owner_estated(addres)
        result = "ID твоих домов:\n"
        for results in result_list:
            result = f"{result}{results[6]},"
        result = result[:-1]


        QtWidgets.QMessageBox.information(self.main_window, "Информация",result,QtWidgets.QMessageBox.Ok)


    def check_home_id(self):
        ID_estate = self.ui_main.line_tab2_id_home.text()
        if ID_estate != "":
            try:
                ID_estate = int(ID_estate)
                result = self.works.check_home_ID(ID_estate)
                if result == False:
                    QtWidgets.QMessageBox.warning(self.main_window,"Предупреждение", "Такого дома не существует",QtWidgets.QMessageBox.Ok)
                else:
                    QtWidgets.QMessageBox.information(self.main_window,"Информация", result,QtWidgets.QMessageBox.Ok)
            except ValueError:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение","Это поле должно быть цифрой",QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение","Это поле не должно быть пустым", QtWidgets.QMessageBox.Ok)
        


    def create_estate(self):
        addres_from = self.ui_main.comboBox_2.currentText()
        addres_to = self.ui_main.comboBox_3.currentText()
        square = self.ui_main.line_squer.text()
        info = self.ui_main.line_info.text()
        if square != "" and info !="":
            try:
                square = int(square)
                self.w3w.create_estate(addres_to, info, square, addres_from)
                QtWidgets.QMessageBox.information(self.main_window, "Информация", "Дом был создан!", QtWidgets.QMessageBox.Ok)
                self.start_tabel_test()
            except ValueError:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "поле squer должен быть числом", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Все поля должны быть заполнены", QtWidgets.QMessageBox.Ok)


    def account_change(self, s):
        self.config_main(s)
        result = self.w3w.check_admin()
        if result == s:
            self.ui_main.line_info.show()
            self.ui_main.line_squer.show()
            self.ui_main.comboBox_3.show()
            self.ui_main.btn_create.show()
            self.ui_main.label_4.show()
            self.ui_main.label_7.show()
            self.ui_main.label_8.show()
        else:
            self.ui_main.line_info.hide() 
            self.ui_main.line_squer.hide() 
            self.ui_main.comboBox_3.hide() 
            self.ui_main.btn_create.hide() 
            self.ui_main.label_4.hide() 
            self.ui_main.label_7.hide() 
            self.ui_main.label_8.hide() 
        

    def create_comBox_account_present(self):
        self.ui_main.comboBox.clear()
        address = self.ui_main.comboBox_2.currentText()
        account = self.w3w.accounts()
        for result in account:
            if address != result:
                self.ui_main.comboBox.addItem(result)
            else:
                pass


    def create_comBox_account(self):
        account = self.w3w.accounts()
        for result in account:
            self.ui_main.comboBox_2.addItem(result)
            self.ui_main.comboBox_3.addItem(result)

    
    def create_present(self):
        address = self.ui_main.comboBox_2.currentText()
        ID_home = self.ui_main.line_tab2_id_home_you.text()
        address_to = self.ui_main.comboBox.currentText()

        if ID_home != "":
            try:
                ID_home = int(ID_home)
                result = self.works.create_Present(address_to, address, ID_home)
                if result == True:
                    QtWidgets.QMessageBox.information(self.main_window, "Информация", "Успех, подарок отправлен", QtWidgets.QMessageBox.Ok)
                    self.fill_table()
                else:
                    QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", result, QtWidgets.QMessageBox.Ok)
            except ValueError:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строка содержит буквы, а не ID", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строка пустая,ввидите ID подарка", QtWidgets.QMessageBox.Ok)
    

    def accept_present(self):
        address = self.ui_main.comboBox_2.currentText()
        ID_line = self.ui_main.line_tab2_id_present.text()
        if ID_line != "":
            try:
                ID_line = int(ID_line)
                result = self.works.accept_present(ID_line, address)
                if result:
                    QtWidgets.QMessageBox.information(self.main_window, "Информация", "Подарок получен")
                    self.fill_table()
                else:
                    QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", result)

            except ValueError:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "ID должен быть цифрой")
        else:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строчка ID не должна быть пустой")


    def refuse_present(self):
        address = self.ui_main.comboBox_2.currentText()
        ID_line = self.ui_main.line_tab2_id_present.text()
        if ID_line != "":
            try:
                ID_line = int(ID_line)
                result = self.works.refuse_present(ID_line, address)
                if result:
                    QtWidgets.QMessageBox.information(self.main_window, "Информация", "Вы отказались от подарка")
                    self.fill_table()
                else:
                    QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", result)

            except ValueError:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "ID должен быть цифрой")
        else:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строчка ID не должна быть пустой")     

    def reconsider_presetn(self):
        address = self.ui_main.comboBox_2.currentText()
        ID_present = self.ui_main.line_tab2_id_present_you.text()
        if ID_present != "":
            try:
                ID_present = int(ID_present)
                result = self.works.reconsider_Present(address, ID_present)
                if result == True:
                    QtWidgets.QMessageBox.information(self.main_window, "Информация", "Успех, подарок отменён", QtWidgets.QMessageBox.Ok)
                    self.fill_table()
                else:
                    QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", result, QtWidgets.QMessageBox.Ok)
            except ValueError:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строка содержит буквы", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строка пустая,ввидите ID подарка", QtWidgets.QMessageBox.Ok)

######################################################################################

    def Sel_info_windows(self):
        result = self.check_info_sell()
        if result:
            self.sel_info_window = QtWidgets.QMainWindow()
            self.ui_sel_info = Ui_sel_win()
            self.ui_sel_info.setupUi(self.sel_info_window)
            self.sel_info_window.show()
        else:
            pass


    def start_tabel_work_sell(self):
        if self.sel_info_window.isVisible():
            print("Task run")
            threading.Timer(30, self.start_tabel_work_sell(self.ids_sell))
            self.tabel_sell()
        else:
            print("Task Stop")


    def check_info_sell(self):
        self.ids_sell = self.ui_main.tab_3_line_id_sell.text()
        list_sell = self.w3w.Get_sells_list()
        try:
            self.ids_sell = int(self.ids_sell)
            if self.ids_sell != "":
                if list_sell >= self.ids_sell:
                        return True
                else:
                    QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Такого аукциона нету", QtWidgets.QMessageBox.Ok)
                    return False
            else:
                QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строка должна содержать ID", QtWidgets.QMessageBox.Ok)
                return False
        except ValueError:
            QtWidgets.QMessageBox.warning(self.main_window, "Предупреждение", "Строка должна содержать цифры", QtWidgets.QMessageBox.Ok)
            return False
    
    def tabel_sell(self,ids):
        self.ui_sel_info.table_sel_info.setRowCount(0)
        sells = self.works.check_sell_id(ids)
        for bids, people in zip(sells[5], sells[4]):
            row_position = self.ui_sel_info.table_sel_info.rowCount()
            self.ui_sel_info.table_sel_info.insertRow(row_position)     
            self.ui_sel_info.table_sel_info.setItem(row_position, 0,  QtWidgets.QTableWidgetItem(str(bids)))  
            self.ui_sel_info.table_sel_info.setItem(row_position, 1,  QtWidgets.QTableWidgetItem(str(people))) 


######################################################################################

    def Sel_info_you_windows(self):
        result = self.check_info_sell()
        if result:
            self.sel_info_you_window = QtWidgets.QMainWindow()  
            self.ui_sel_you = Ui_sell_you() 
            self.ui_sel_you.setupUi(self.sel_info_you_window)
            self.sel_info_you_window.show() 
            self.tabel_sell(self.ids_sell)
        else:
            pass
    



if __name__ == "__main__":
    app = MyApp(sys.argv)
    app.Main_windows()
    sys.exit(app.exec_())
