from w3s import CWW

class Work():
    def __init__(self):
        self.cw3 = CWW()


    def check_owner_estated(self, address):
        rang = self.cw3.get_list_estate()
        res = []
        check = 0
        for i in range(rang):
            result = self.cw3.estate_info(i)
            if result[0] == address:
                result.append(check)
                res.append(result)
            check += 1
        return res
    


    def check_bid(self, id_sell,address,bid):
        N = False
        result = self.cw3.getSell(id_sell)
        if result[1] != address:
            for adr in result[4]:
                if adr == address:
                    if adr[5] == 0:
                        N = True
            if N:
                balance = self.cw3.Balance_OF(adr)
                balance = int(balance)
                if balance >= bid and result[3] <= bid:
                    self.cw3.make_bid(bid,id_sell, address)



    def check_sell_id(self, sale_id):
        return self.cw3.getSell(sale_id)

    def check_sell(self,address):
        rang = self.cw3.Get_sells_list()
        res = []
        check = 0
        for i in range(rang):
            result = self.cw3.getSell(i)
            if result[1] != address:
                result.append(check)
                res.append(result)
            check +=1
        return res

    def check_owner_sell(self,address):
        rang = self.cw3.Get_sells_list()
        res = []
        check = 0
        for i in range(rang):
            result = self.cw3.getSell(i)
            if result[1] == address:
                result.append(check)
                res.append(result)
            check +=1
        return res

    def check_owner_present(self, address):
        rang = self.cw3.get_list_present()
        res = []
        for i in range(rang):
            check += 1
            result = self.cw3.getPresent(i)
            if result[1] == address or result[2] == address:
                result.append(check)
                res.append(result)
        return res
    

    def reconsider_Present(self, address, ID_present):
        line_present = self.cw3.get_list_present()
        if line_present >= ID_present:
            present_check = self.cw3.getPresent(ID_present)
            if present_check[1] == address:
                if present_check[4] in [1,2,3,4]:
                    return "Подарок был уже отменён или получен"
                else:
                    self.cw3.reconsider_present(ID_present, address)
                    return True
        else:
            return "Такого ID не существуе"
    

    def create_Present(self, address_to,addres_owner,ID_estate):
        line_estate = self.cw3.get_list_estate()
        if line_estate >= ID_estate:
            estate_list = self.check_owner_estated(addres_owner)
            for estate_lists in estate_list:
                if estate_lists[0] == addres_owner:
                    if estate_lists[5] == False and estate_lists[4] == False and estate_lists[3] == False:
                        self.cw3.create_presents(ID_estate, address_to, addres_owner)
                        return True
                    else:
                        return "Вашь дом продаётся или уже в процесе дарение или арестован"
                else:
                    pass
            return "Вы не владалец этого дома"
        else:
            return "Такого дома не существует"
    

    def accept_present(self,ID_present,addres):
        line_present = self.cw3.get_list_present()
        if line_present >= ID_present:
            result = self.cw3.getPresent(ID_present)
            if result[2] == addres:
                check = self.cw3.estate_info(result[0])
                if result[4] in [1,2,3,4] and check[3] == True:
                    return "Подарок был отменён или получен или вы не успели его забрать"
                else:
                    self.cw3.accept_Present(ID_present,addres)
                    return True
            else:
                return "Вы не получатель подарка"
        else:
            return "Такого подарко не существует" 


    def refuse_present(self,ID_present,addres):
        line_present = self.cw3.get_list_present()
        if line_present >= ID_present:
            result = self.cw3.getPresent(ID_present)#2/3
            if result[2] == addres:
                check = self.cw3.estate_info(result[0])
                if result[4] in [1,2,3,4] and check[3] == True:
                    return "Подарок был отменён или получен или вы не успели его забрать"
                else:
                    self.cw3.refuse_present(ID_present,addres)
                    return True
            else:
                return "Вы не получатель подарка"
        else:
            return "Такого подарко не существует" 


    def check_home_ID(self, ID_estate):
        line_estate = self.cw3.get_list_estate()
        if line_estate >= ID_estate:
            list = self.cw3.estate_info(ID_estate)
            result =f""" 
            ID:{ID_estate}
            Владелец:{list[0]}
            Информация:{list[1]}
            Площадь:{list[2]}
            Арест:{list[5]}
            Продажа:{list[4]}
            Подарок:{list[3]}
            """
            return result
        else:
            return False



if __name__ == "__main__":
    s = Work()
    cw3 = CWW()
    
    d = s.check_sell("s")
    print(d)
